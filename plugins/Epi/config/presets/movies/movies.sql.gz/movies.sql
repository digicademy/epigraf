/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.2-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql    Database: epi_movies
-- ------------------------------------------------------
-- Server version	10.11.6-MariaDB-1:10.11.6+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `articletype` varchar(50) DEFAULT NULL,
  `signature` varchar(1500) DEFAULT NULL,
  `name` varchar(1500) DEFAULT NULL,
  `sortno` int(11) DEFAULT NULL,
  `status` varchar(1500) DEFAULT NULL,
  `norm_data` varchar(1500) DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  `norm_type` varchar(1500) DEFAULT NULL,
  `lastopen_id` int(11) DEFAULT NULL,
  `lastopen_tab` varchar(500) DEFAULT NULL,
  `lastopen_field` varchar(500) DEFAULT NULL,
  `lastopen_tagid` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `projects_id` (`projects_id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `lastopen_id` (`lastopen_id`),
  KEY `lastopen_tab` (`lastopen_tab`(255)),
  KEY `lastopen_feld` (`lastopen_field`(255)),
  KEY `lastopen_subid` (`lastopen_tagid`(255)),
  KEY `published` (`published`),
  KEY `articletype` (`articletype`),
  KEY `deleted` (`deleted`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `articles` VALUES
(1,1,0,NULL,61245,NULL,'2024-11-27 22:22:38','2024-12-15 18:15:40',NULL,NULL,'default','001','2001: A Space Odyssey',1,NULL,NULL,'movies~001',NULL,NULL,NULL,NULL,NULL),
(2,1,0,NULL,61245,NULL,'2024-11-27 22:22:38','2024-12-15 18:15:45',NULL,NULL,'default','002','Spartacus',2,NULL,NULL,'movies~002',NULL,NULL,NULL,NULL,NULL),
(5,1,0,NULL,61245,NULL,'2024-12-15 17:03:01','2024-12-15 17:23:25',NULL,NULL,'default','003','Gladiator',3,NULL,NULL,'movies~003',NULL,NULL,NULL,NULL,NULL),
(6,1,0,NULL,61245,NULL,'2024-12-15 17:03:01','2024-12-15 17:23:25',NULL,NULL,'default','004','The Godfather',4,NULL,NULL,'movies~004',NULL,NULL,NULL,NULL,NULL),
(7,1,0,NULL,61245,NULL,'2024-12-15 17:03:01','2024-12-15 17:23:25',NULL,NULL,'default','005','Star Wars',5,NULL,NULL,'movies~005',NULL,NULL,NULL,NULL,NULL),
(8,1,0,NULL,61245,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:25',NULL,NULL,'default','006','Superbad',6,NULL,NULL,'movies~006',NULL,NULL,NULL,NULL,NULL),
(9,1,0,NULL,61245,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:25',NULL,NULL,'default','007','Pirates of the Caribbean',7,NULL,NULL,'movies~007',NULL,NULL,NULL,NULL,NULL),
(10,1,0,NULL,61245,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:25',NULL,NULL,'default','008','The Lord of the Rings',8,NULL,NULL,'movies~008',NULL,NULL,NULL,NULL,NULL),
(11,1,0,NULL,61245,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:25',NULL,NULL,'default','009','The Chronicles of Narnia',9,NULL,NULL,'movies~009',NULL,NULL,NULL,NULL,NULL),
(12,1,0,NULL,61245,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:25',NULL,NULL,'default','010','La La Land',10,NULL,NULL,'movies~010',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `name` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `root` varchar(100) DEFAULT 'root',
  `path` varchar(500) DEFAULT NULL,
  `isfolder` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `published` (`published`),
  KEY `name` (`name`(250)),
  KEY `type` (`type`),
  KEY `path` (`path`(250)),
  KEY `root` (`root`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `footnotes`
--

DROP TABLE IF EXISTS `footnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `footnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `sortno` int(11) DEFAULT NULL,
  `fntype` tinyint(1) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `segment` text DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `root_id` int(11) DEFAULT NULL,
  `root_tab` varchar(500) DEFAULT NULL,
  `from_id` int(11) DEFAULT NULL,
  `from_tab` varchar(500) DEFAULT NULL,
  `from_field` varchar(500) DEFAULT NULL,
  `from_tagname` varchar(50) DEFAULT NULL,
  `from_tagid` varchar(500) DEFAULT NULL,
  `from_sort` int(11) DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `rootrecord_id` (`root_id`),
  KEY `rootrecord_tab` (`root_tab`(255)),
  KEY `published` (`published`),
  KEY `fntype` (`fntype`),
  KEY `from_tagname` (`from_tagname`),
  KEY `deleted` (`deleted`) USING BTREE,
  KEY `from_id` (`from_id`) USING BTREE,
  KEY `from_tab` (`from_tab`(255)) USING BTREE,
  KEY `from_field` (`from_field`(255)) USING BTREE,
  KEY `from_tagid` (`from_tagid`(255)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footnotes`
--

LOCK TABLES `footnotes` WRITE;
/*!40000 ALTER TABLE `footnotes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `footnotes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `grains`
--

DROP TABLE IF EXISTS `grains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `grains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `sortno` int(11) DEFAULT NULL,
  `graintype` varchar(500) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `file_name` varchar(1500) DEFAULT NULL,
  `file_type` varchar(10) DEFAULT NULL,
  `file_path` varchar(1500) DEFAULT NULL,
  `file_source` varchar(1500) DEFAULT NULL,
  `file_copyright` text DEFAULT NULL,
  `links_tab` varchar(50) DEFAULT NULL,
  `links_id` int(11) DEFAULT NULL,
  `properties_id` int(11) DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deleted` (`deleted`),
  KEY `properties_id` (`properties_id`),
  KEY `sortno` (`sortno`),
  KEY `itemtype` (`graintype`(255)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grains`
--

LOCK TABLES `grains` WRITE;
/*!40000 ALTER TABLE `grains` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `grains` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `status` varchar(1500) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `sortno` int(11) DEFAULT NULL,
  `itemtype` varchar(500) DEFAULT NULL,
  `itemgroup` varchar(100) DEFAULT NULL,
  `properties_id` int(11) DEFAULT NULL,
  `value` varchar(1500) DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `translation` text DEFAULT NULL,
  `flagged` tinyint(1) DEFAULT NULL,
  `links_id` int(11) DEFAULT NULL,
  `links_tab` varchar(500) DEFAULT NULL,
  `links_field` varchar(500) DEFAULT NULL,
  `links_tagid` varchar(500) DEFAULT NULL,
  `file_name` varchar(1500) DEFAULT NULL,
  `file_type` varchar(10) DEFAULT NULL,
  `file_path` varchar(1500) DEFAULT NULL,
  `file_source` varchar(1500) DEFAULT NULL,
  `file_copyright` text DEFAULT NULL,
  `file_meta` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `file_online` tinyint(1) DEFAULT NULL,
  `date_sort` varchar(1500) DEFAULT NULL,
  `date_value` varchar(1500) DEFAULT NULL,
  `date_add` text DEFAULT NULL,
  `date_start` double DEFAULT NULL,
  `date_end` double DEFAULT NULL,
  `source_autopsy` tinyint(1) DEFAULT NULL,
  `source_from` text DEFAULT NULL,
  `source_addition` text DEFAULT NULL,
  `pos_x` int(11) DEFAULT NULL,
  `pos_y` int(11) DEFAULT NULL,
  `pos_z` int(11) DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  `articles_id` int(11) DEFAULT NULL,
  `sections_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `properties_id` (`properties_id`),
  KEY `orderidx` (`sortno`),
  KEY `sections_id` (`sections_id`),
  KEY `articles_id` (`articles_id`),
  KEY `published` (`published`),
  KEY `file_name` (`file_name`(768)),
  KEY `file_path` (`file_path`(768)),
  KEY `file_type` (`file_type`),
  KEY `deleted` (`deleted`) USING BTREE,
  KEY `itemtype` (`deleted`,`itemtype`(255)) USING BTREE,
  KEY `countbyarticle` (`deleted`,`itemtype`,`articles_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `items` VALUES
(1,0,NULL,61245,NULL,NULL,'2024-11-27 22:22:38','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~001~categories~genre',1,1),
(2,0,NULL,61245,NULL,NULL,'2024-11-27 22:22:38','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'2001: A Space Odyssey 🚀 is an epic sci-fi movie that tells the journey of astronauts and a mysterious monolith. The film is known for its stunning visual effects and the iconic AI HAL 9000. Its narrative explores themes of human evolution, technology, and artificial intelligence. Director Stanley Kubrick\'s meticulous attention to detail and innovative use of music set a new standard for the genre. The movie\'s ambiguous and philosophical ending continues to inspire debate and analysis.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~001~description~summary',1,2),
(3,0,NULL,61245,NULL,NULL,'2024-11-27 22:22:38','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~002~categories~genre',2,3),
(4,0,NULL,61245,NULL,NULL,'2024-11-27 22:22:38','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'Spartacus ⚔️ is an epic historical film about the revolt of a slave against the Roman Empire. The film is known for its impressive battle scenes and the inspiring story of freedom and justice. It highlights the harsh realities of slavery and the indomitable human spirit striving for liberation. Directed by Stanley Kubrick, it features a powerful performance by Kirk Douglas in the leading role. The film\'s large scale and authentic portrayal of ancient Rome brought it critical acclaim.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~002~description~summary',2,4),
(5,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~003~categories~genre',5,9),
(6,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'Gladiator 🏟️ is a gripping tale of power and revenge in the Roman Empire. The film portrays a Roman general who is betrayed and his family murdered by an emperor\'s corrupt son. He comes to Rome as a gladiator seeking revenge. Directed by Ridley Scott, this film features intense performances and epic fight scenes. Its historical inaccuracies are eclipsed by its dramatic depth and strong narrative.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~003~description~summary',5,10),
(7,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~004~categories~genre',6,11),
(8,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'The Godfather 🕴️ is a dramatic saga of a powerful mafia family and their complex web of loyalty, betrayal, and ambition. Directed by Francis Ford Coppola, it offers a deep dive into the American mafia landscape of the 1940s and 1950s. The film is praised for its rich character development and masterful storytelling. Marlon Brando\'s iconic portrayal of Vito Corleone is a standout in cinematic history. The movie\'s impact on film and culture is profound, spawning sequels and numerous imitations.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~004~description~summary',6,12),
(9,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~005~categories~genre',7,13),
(10,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'Star Wars 🌌 is a monumental franchise set in a galaxy far, far away. The series blends elements of fantasy and sci-fi, featuring epic battles between the dark and light sides of the Force. Iconic characters like Luke Skywalker, Darth Vader, and Yoda are central to its storytelling. The franchise has expanded over decades, influencing multiple generations with its themes of heroism, redemption, and the struggle against tyranny. Star Wars remains a cultural phenomenon with a massive fanbase around the world.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~005~description~summary',7,14),
(11,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~006~categories~genre',8,15),
(12,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'Superbad 🍻 is a coming-of-age comedy that follows two high school friends trying to make the most of their remaining time before college. The film captures the awkwardness and excitement of teenage years. Its humor is both raunchy and heartfelt, resonating with a wide audience. Jonah Hill and Michael Cera deliver performances that perfectly embody teenage angst and friendship. The movie has become a cultural icon, influencing a generation\'s view of high school comedies.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~006~description~summary',8,16),
(13,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~007~categories~genre',9,17),
(14,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'Pirates of the Caribbean 🏴‍☠️ is a swashbuckling adventure set on the high seas. This film series follows the charismatic and cunning Captain Jack Sparrow as he navigates the treacherous waters of the Caribbean. The franchise is known for its blend of fantasy, action, and humor, featuring cursed pirates and mystical sea lore. Its visually stunning scenes and epic naval battles have captivated audiences worldwide, making it a standout in the fantasy genre.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~007~description~summary',9,18),
(15,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~008~categories~genre',10,19),
(16,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'The Lord of the Rings 🗡️ is an epic fantasy adventure about the quest to destroy a powerful ring that threatens the world. Directed by Peter Jackson, the trilogy showcases the vast world of Middle Earth filled with elves, dwarves, and orcs. The films are noted for their groundbreaking special effects and epic storytelling. The ensemble cast brings depth to each character, making every moment of the journey emotionally engaging. The trilogy has not only won numerous awards but also captured the hearts of a global audience.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~008~description~summary',10,20),
(17,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~009~categories~genre',11,21),
(18,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'The Chronicles of Narnia 🦁 is a series of films based on the novels by C.S. Lewis. They recount the adventures of children who discover a magical land called Narnia through a wardrobe. The films explore themes of good versus evil, faith, and redemption. They are beloved for their imaginative storytelling and the rich, fantastical world they bring to life.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~009~description~summary',11,22),
(19,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2025-04-18 06:39:06',NULL,NULL,1,'categories',NULL,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~010~categories~genre',12,23),
(20,0,NULL,61245,NULL,NULL,'2024-12-15 17:03:02','2024-12-15 17:23:26',NULL,NULL,1,'text',NULL,NULL,NULL,'La La Land 🎹 is a musical romance that captures the joy and pain of pursuing dreams in a vibrant depiction of Los Angeles. The film combines jazz music with classic and modern dance sequences to create a visually stunning experience. The chemistry between Emma Stone and Ryan Gosling drives the narrative, filled with romance and heartbreak. Directed by Damien Chazelle, it reinvigorates the musical genre with a fresh modern twist. The film\'s critical and commercial success has sparked renewed interest in musical cinema.',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'movies~010~description~summary',12,24);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `root_id` int(11) DEFAULT NULL,
  `root_tab` varchar(500) DEFAULT NULL,
  `from_id` int(11) DEFAULT NULL,
  `from_tab` varchar(500) DEFAULT NULL,
  `from_field` varchar(500) DEFAULT NULL,
  `from_tagname` varchar(50) DEFAULT NULL,
  `from_tagid` varchar(500) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `to_tab` varchar(500) DEFAULT NULL,
  `to_field` varchar(500) DEFAULT NULL,
  `to_tagid` varchar(500) DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `rootrecord_id` (`root_id`),
  KEY `rootrecord_tab` (`root_tab`(255)),
  KEY `published` (`published`),
  KEY `from_tagname` (`from_tagname`),
  KEY `deleted` (`deleted`) USING BTREE,
  KEY `from_id` (`from_id`) USING BTREE,
  KEY `from_tab` (`from_tab`(255)) USING BTREE,
  KEY `from_field` (`from_field`(255)) USING BTREE,
  KEY `from_tagid` (`from_tagid`(255)) USING BTREE,
  KEY `to_id` (`to_id`) USING BTREE,
  KEY `to_tab` (`to_tab`(255)) USING BTREE,
  KEY `to_field` (`to_field`(255)) USING BTREE,
  KEY `to_tagid` (`to_tagid`(255)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `locktable`
--

DROP TABLE IF EXISTS `locktable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `locktable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lock_token` int(11) DEFAULT NULL,
  `lock_mode` int(11) DEFAULT NULL,
  `lock_table` varchar(1500) DEFAULT NULL,
  `lock_segment` varchar(255) DEFAULT NULL,
  `lock_id` int(11) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lockid` (`lock_token`),
  KEY `lockdatensatz` (`lock_id`),
  KEY `lockmode` (`lock_mode`),
  KEY `locksegment` (`lock_segment`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locktable`
--

LOCK TABLES `locktable` WRITE;
/*!40000 ALTER TABLE `locktable` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `locktable` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `meta`
--

DROP TABLE IF EXISTS `meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `name` varchar(1500) DEFAULT NULL,
  `value` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `deleted` (`deleted`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta`
--

LOCK TABLES `meta` WRITE;
/*!40000 ALTER TABLE `meta` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `meta` VALUES
(1,0,'0000-00-00 00:00:00','2024-11-27 22:22:32',NULL,NULL,'db_version','4.5'),
(2,0,'0000-00-00 00:00:00','2024-11-27 22:22:32',NULL,NULL,'db_name','Epigraf');
/*!40000 ALTER TABLE `meta` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `menu` tinyint(4) NOT NULL DEFAULT 1,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `notetype` varchar(50) DEFAULT NULL,
  `name` char(200) DEFAULT NULL,
  `category` varchar(300) DEFAULT NULL,
  `sortkey` varchar(50) DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `format` varchar(15) NOT NULL DEFAULT 'html',
  `norm_iri` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `projecttype` varchar(50) DEFAULT NULL,
  `sortno` int(11) DEFAULT NULL,
  `name` varchar(1500) DEFAULT NULL,
  `signature` varchar(1500) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `norm_data` varchar(1500) DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `published` (`published`),
  KEY `deleted` (`deleted`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projects` VALUES
(1,0,NULL,NULL,NULL,'2024-11-27 22:22:38','2024-12-15 18:16:27',NULL,NULL,'default',NULL,'Movies','movies',NULL,NULL,'movies');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `status` varchar(1500) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `sortno` int(11) DEFAULT NULL,
  `sortkey` varchar(1500) DEFAULT NULL,
  `propertytype` varchar(500) DEFAULT NULL,
  `signature` varchar(1500) DEFAULT NULL,
  `file_name` varchar(1500) DEFAULT NULL,
  `properties_id` int(11) DEFAULT NULL,
  `lemma` varchar(1500) DEFAULT NULL,
  `name` varchar(1500) DEFAULT NULL,
  `unit` varchar(500) DEFAULT NULL,
  `comment` mediumtext DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `elements` text DEFAULT NULL,
  `keywords` varchar(1500) DEFAULT NULL,
  `source_from` text DEFAULT NULL,
  `ishidden` tinyint(4) DEFAULT NULL,
  `iscategory` tinyint(4) DEFAULT NULL,
  `norm_type` varchar(150) DEFAULT NULL,
  `norm_data` text DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  `import_db` varchar(1500) DEFAULT NULL,
  `import_id` varchar(1500) DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `mergedto_id` int(11) DEFAULT NULL,
  `splitfrom_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `propertytype` (`propertytype`(255)),
  KEY `sortno` (`sortno`),
  KEY `parent_id` (`parent_id`),
  KEY `published` (`published`),
  KEY `related_id` (`related_id`),
  KEY `deleted` (`deleted`) USING BTREE,
  KEY `lemma` (`lemma`(768)),
  KEY `tree` (`deleted`,`propertytype`,`level`,`lft`),
  KEY `lft` (`deleted`,`propertytype`,`lft`) USING BTREE,
  KEY `rght` (`deleted`,`propertytype`,`rght`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties`
--

LOCK TABLES `properties` WRITE;
/*!40000 ALTER TABLE `properties` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `properties` VALUES
(1,0,NULL,NULL,NULL,NULL,'2024-11-27 22:22:38','2025-04-18 06:39:43',NULL,NULL,NULL,NULL,'categories',NULL,NULL,NULL,'History',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'history',NULL,NULL,NULL,NULL,NULL,NULL,0,1,2),
(2,0,NULL,NULL,NULL,NULL,'2024-11-27 22:22:38','2025-04-18 06:39:43',NULL,NULL,NULL,NULL,'categories',NULL,NULL,NULL,'Scifi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'scifi',NULL,NULL,NULL,NULL,NULL,NULL,0,3,4),
(3,0,NULL,NULL,NULL,NULL,'2024-12-15 16:37:01','2025-04-18 06:39:52',NULL,NULL,NULL,NULL,'annotations',NULL,NULL,NULL,'Protagonist',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'protagonist',NULL,NULL,NULL,NULL,NULL,NULL,0,5,6),
(5,0,NULL,NULL,NULL,NULL,'2024-12-15 16:37:15','2025-04-18 06:39:52',NULL,NULL,NULL,NULL,'annotations',NULL,NULL,NULL,'Antagonist',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'antagonist',NULL,NULL,NULL,NULL,NULL,NULL,0,1,2),
(7,0,NULL,NULL,NULL,NULL,'2024-12-15 16:37:28','2025-04-18 06:39:52',NULL,NULL,NULL,NULL,'annotations',NULL,NULL,NULL,'Sidekick',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sidekick',NULL,NULL,NULL,NULL,NULL,NULL,0,7,8),
(9,0,NULL,NULL,NULL,NULL,'2024-12-15 16:38:13','2025-04-18 06:39:52',NULL,NULL,NULL,NULL,'annotations',NULL,NULL,NULL,'Mentor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'mentor',NULL,NULL,NULL,NULL,NULL,NULL,0,3,4),
(11,0,NULL,NULL,NULL,NULL,'2024-12-15 17:03:01','2025-04-18 06:39:43',NULL,NULL,NULL,NULL,'categories',NULL,NULL,NULL,'Musical',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'musical',NULL,NULL,NULL,NULL,NULL,NULL,0,5,6),
(12,0,NULL,NULL,NULL,NULL,'2024-12-15 17:03:01','2025-04-18 06:39:43',NULL,NULL,NULL,NULL,'categories',NULL,NULL,NULL,'Fantasy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fantasy',NULL,NULL,NULL,NULL,NULL,NULL,0,7,8),
(13,0,NULL,NULL,NULL,NULL,'2024-12-15 17:03:01','2025-04-18 06:39:43',NULL,NULL,NULL,NULL,'categories',NULL,NULL,NULL,'Comedy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'comedy',NULL,NULL,NULL,NULL,NULL,NULL,0,9,10),
(14,0,NULL,NULL,NULL,NULL,'2024-12-15 17:03:01','2025-04-18 06:39:43',NULL,NULL,NULL,NULL,'categories',NULL,NULL,NULL,'Drama',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'drama',NULL,NULL,NULL,NULL,NULL,NULL,0,11,12);
/*!40000 ALTER TABLE `properties` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `sortno` int(11) NOT NULL DEFAULT 0,
  `layout_cols` int(11) NOT NULL DEFAULT 0,
  `layout_rows` int(11) NOT NULL DEFAULT 0,
  `sectiontype` varchar(200) NOT NULL DEFAULT '',
  `number` int(11) DEFAULT NULL,
  `name` varchar(1500) DEFAULT NULL,
  `alias` varchar(1500) DEFAULT NULL,
  `comment` mediumtext DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  `articles_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `articles_id` (`articles_id`),
  KEY `sectiontype` (`sectiontype`),
  KEY `published` (`published`),
  KEY `deleted` (`deleted`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES
(1,0,NULL,61245,NULL,'2024-11-27 22:22:38','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~001~categories',1),
(2,0,NULL,61245,NULL,'2024-11-27 22:22:38','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~001~description',1),
(3,0,NULL,61245,NULL,'2024-11-27 22:22:38','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~002~categories',2),
(4,0,NULL,61245,NULL,'2024-11-27 22:22:38','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~002~description',2),
(9,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~003~categories',5),
(10,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~003~description',5),
(11,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~004~categories',6),
(12,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~004~description',6),
(13,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~005~categories',7),
(14,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~005~description',7),
(15,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~006~categories',8),
(16,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~006~description',8),
(17,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~007~categories',9),
(18,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~007~description',9),
(19,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~008~categories',10),
(20,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~008~description',10),
(21,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~009~categories',11),
(22,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~009~description',11),
(23,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:41:18',NULL,NULL,2,0,0,'categories',NULL,'Genres','',NULL,NULL,NULL,0,3,4,'movies~010~categories',12),
(24,0,NULL,61245,NULL,'2024-12-15 17:03:02','2025-04-18 06:42:42',NULL,NULL,1,0,0,'text',NULL,'Abstract','',NULL,NULL,NULL,0,1,2,'movies~010~description',12);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `usertoken` varchar(255) DEFAULT NULL,
  `sessiontoken` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `userrole` (`usertoken`),
  KEY `deleted` (`deleted`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `types`
--

DROP TABLE IF EXISTS `types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `published` tinyint(4) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `scope` varchar(50) DEFAULT NULL,
  `mode` varchar(50) NOT NULL DEFAULT 'default',
  `preset` varchar(50) NOT NULL DEFAULT 'default',
  `name` varchar(100) DEFAULT NULL,
  `sortno` int(11) NOT NULL DEFAULT 0,
  `category` varchar(100) DEFAULT NULL,
  `caption` varchar(200) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `config` mediumtext DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sortno` (`sortno`),
  KEY `deleted` (`deleted`) USING BTREE,
  KEY `name` (`deleted`,`scope`,`name`) USING BTREE,
  KEY `mode` (`deleted`,`scope`,`name`,`preset`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types`
--

LOCK TABLES `types` WRITE;
/*!40000 ALTER TABLE `types` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `types` VALUES
(1,0,NULL,NULL,0,'2024-11-27 22:22:36','2025-04-18 06:51:30',NULL,1,'links','default','default','anno',80,'Annotations','Figure','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf5a1\",\"font\":\"awesome\",\"style\":\"color: #4dcf20;\"},\"tag_type\":\"format\",\"css_style\":\".xml_tag_anno { background-color:#b6ff9d88; }\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annotations\"]}}}}','anno~default'),
(2,0,NULL,NULL,0,'2024-11-27 22:22:36','2025-04-18 06:40:57',NULL,1,'properties','default','default','categories',70,'Categories','Genres','','{\"fields\":{\"lemma\":{\"caption\":\"Genre\"}}}','categories~default'),
(3,0,NULL,NULL,0,'2024-11-27 22:22:36','2025-04-18 06:34:40',NULL,1,'items','default','default','categories',60,'Categories','Genre','','{\"fields\":{\"property\":{\"format\":\"property\",\"caption\":\"Genre\",\"types\":\"categories\"}}}','categories~default'),
(4,0,NULL,NULL,0,'2024-11-27 22:22:36','2025-04-18 06:40:48',NULL,1,'sections','default','default','categories',50,'Categories','Genres','','{\"items\":{\"categories\":{\"type\":\"categories\"}}}','categories~default'),
(5,0,NULL,NULL,0,'2024-11-27 22:22:36','2024-12-15 18:21:27',NULL,NULL,'items','default','default','text',40,'Content','Text','','{\"fields\":{\"content\":{\"format\":\"xml\",\"types\":\"annos\"}}}','text~default'),
(6,0,NULL,NULL,0,'2024-11-27 22:22:36','2025-04-18 06:42:29',NULL,1,'sections','default','default','text',30,'Content','Abstract','','{\"items\":{\"text\":{\"type\":\"text\"}}}','text~default'),
(7,0,NULL,NULL,0,'2024-11-27 22:22:36','2024-12-15 18:21:27',NULL,NULL,'articles','default','default','default',20,'Content','Default','','{\"fields\":{\"signature\":\"Case\",\"name\":\"Title\",\"projects_id\":\"Project\",\"modified\":\"Modified\"},\"columns\":{\"signature\":{\"caption\":\"Case\",\"default\":true},\"name\":{\"caption\":\"Title\",\"default\":true},\"modfied\":{\"key\":\"modified\",\"caption\":\"Last modified\"},\"project_name\":{\"caption\":\"Project\",\"key\":\"project.name\",\"default\":true}},\"footnotes\":[\"memo\"]}','default~default'),
(8,0,NULL,NULL,0,'2024-11-27 22:22:36','2024-12-15 18:21:27',NULL,NULL,'projects','default','default','default',10,'Content','Default','','{}','default~default'),
(10,0,NULL,NULL,0,'2024-12-15 15:52:21','2025-04-18 06:51:39',NULL,1,'footnotes','default','default','memo',100,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf075\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"prefix\":\"[\",\"postfix\":\"]\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default'),
(20,0,NULL,NULL,0,'2024-12-15 15:56:11','2025-04-18 06:43:26',NULL,1,'properties','default','default','annotations',90,'Categories','Figures','','{\"fields\":{\"lemma\":{\"caption\":\"Name\"}}}','annotations~default'),
(21,2,1,NULL,0,'2025-04-18 06:29:40','2025-04-18 06:29:40',1,1,'links','default','default','fig',80,'Annotations','Figures','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf007\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"css_style\":\".xml_tag_annos > .xml_bracket_open, .xml_tag_annos > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"html_tag\":\"span\",\"html_prefix\":\"[\",\"html_postfix\":\"]\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annos\"]}}}}','figures~default'),
(22,2,1,NULL,0,'2025-04-18 06:31:30','2025-04-18 06:31:30',1,1,'links','default','default','anno',80,'Annotations','Figures','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf007\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"css_style\":\".xml_tag_annos > .xml_bracket_open, .xml_tag_annos > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"html_tag\":\"span\",\"html_prefix\":\"[\",\"html_postfix\":\"]\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annos\"]}}}}','anno~default'),
(23,2,20,NULL,0,'2025-04-18 06:32:07','2025-04-18 06:32:07',1,1,'properties','default','default','annotations',100,'Annotations','Figures','','{\"fields\":{\"lemma\":{\"caption\":\"Name\"}}}','annotations~default'),
(24,2,1,NULL,0,'2025-04-18 06:32:18','2025-04-18 06:32:18',1,1,'links','default','default','anno',80,'Annotations','Figures','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf007\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"css_style\":\".xml_tag_annos > .xml_bracket_open, .xml_tag_annos > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"html_tag\":\"span\",\"html_prefix\":\"[\",\"html_postfix\":\"]\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annotations\"]}}}}','anno~default'),
(25,2,1,NULL,0,'2025-04-18 06:33:04','2025-04-18 06:33:04',1,1,'links','default','default','anno',80,'Annotations','Figures','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf007\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"css_style\":\".xml_tag_anno { background-color:#b6ff9d88; }\",\"html_tag\":\"span\",\"html_prefix\":\"[\",\"html_postfix\":\"]\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annotations\"]}}}}','anno~default'),
(26,2,10,NULL,0,'2025-04-18 06:33:32','2025-04-18 06:33:32',1,1,'footnotes','default','default','memo',70,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf08d\",\"font\":\"awesome\",\"style\":\"color: #4dcf20;\"},\"tag_type\":\"format\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"html_tag\":\"span\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default'),
(27,2,3,NULL,0,'2025-04-18 06:34:40','2025-04-18 06:34:40',1,1,'items','default','default','categories',60,'Categories','Genre','','{\"fields\":{\"property\":{\"format\":\"property\",\"caption\":\"Genre\",\"types\":\"categories\"}}}','categories~default'),
(28,2,4,NULL,0,'2025-04-18 06:35:04','2025-04-18 06:35:04',1,1,'sections','default','default','categories',50,'Categories','Categories','','{\"items\":{\"categories\":{\"type\":\"categories\"}}}','categories~default'),
(29,2,2,NULL,0,'2025-04-18 06:35:42','2025-04-18 06:35:42',1,1,'properties','default','default','categories',90,'Categories','Genre','','{\"fields\":{\"lemma\":{\"caption\":\"Genre\"}}}','categories~default'),
(30,2,2,NULL,0,'2025-04-18 06:36:06','2025-04-18 06:36:06',1,1,'properties','default','default','categories',70,'Categories','Genre','','{\"fields\":{\"lemma\":{\"caption\":\"Genre\"}}}','categories~default'),
(31,2,10,NULL,0,'2025-04-18 06:36:24','2025-04-18 06:36:24',1,1,'footnotes','default','default','memo',90,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf08d\",\"font\":\"awesome\",\"style\":\"color: #4dcf20;\"},\"tag_type\":\"format\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"html_tag\":\"span\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default'),
(32,2,20,NULL,0,'2025-04-18 06:36:46','2025-04-18 06:36:46',1,1,'properties','default','default','annotations',90,'Annotations','Figures','','{\"fields\":{\"lemma\":{\"caption\":\"Name\"}}}','annotations~default'),
(33,2,10,NULL,0,'2025-04-18 06:36:50','2025-04-18 06:36:50',1,1,'footnotes','default','default','memo',100,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf08d\",\"font\":\"awesome\",\"style\":\"color: #4dcf20;\"},\"tag_type\":\"format\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"html_tag\":\"span\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default'),
(34,2,4,NULL,0,'2025-04-18 06:37:24','2025-04-18 06:37:24',1,1,'sections','default','default','categories',50,'Categories','Genre','','{\"items\":{\"categories\":{\"type\":\"categories\"}}}','categories~default'),
(35,2,1,NULL,0,'2025-04-18 06:37:33','2025-04-18 06:37:33',1,1,'links','default','default','anno',80,'Annotations','Figure','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf007\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"css_style\":\".xml_tag_anno { background-color:#b6ff9d88; }\",\"html_tag\":\"span\",\"html_prefix\":\"[\",\"html_postfix\":\"]\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annotations\"]}}}}','anno~default'),
(36,2,20,NULL,0,'2025-04-18 06:37:36','2025-04-18 06:37:36',1,1,'properties','default','default','annotations',90,'Annotations','Figure','','{\"fields\":{\"lemma\":{\"caption\":\"Name\"}}}','annotations~default'),
(37,2,4,NULL,0,'2025-04-18 06:40:48','2025-04-18 06:40:48',1,1,'sections','default','default','categories',50,'Categories','Genres','','{\"items\":{\"categories\":{\"type\":\"categories\"}}}','categories~default'),
(38,2,2,NULL,0,'2025-04-18 06:40:57','2025-04-18 06:40:57',1,1,'properties','default','default','categories',70,'Categories','Genres','','{\"fields\":{\"lemma\":{\"caption\":\"Genre\"}}}','categories~default'),
(39,2,20,NULL,0,'2025-04-18 06:41:01','2025-04-18 06:41:01',1,1,'properties','default','default','annotations',90,'Annotations','Figures','','{\"fields\":{\"lemma\":{\"caption\":\"Name\"}}}','annotations~default'),
(40,2,6,NULL,0,'2025-04-18 06:42:12','2025-04-18 06:42:12',1,1,'sections','default','default','text',30,'Content','Description','','{\"items\":{\"text\":{\"type\":\"text\"}}}','text~default'),
(41,2,6,NULL,0,'2025-04-18 06:42:29','2025-04-18 06:42:29',1,1,'sections','default','default','text',30,'Content','Abstract','','{\"items\":{\"text\":{\"type\":\"text\"}}}','text~default'),
(42,2,20,NULL,0,'2025-04-18 06:43:26','2025-04-18 06:43:26',1,1,'properties','default','default','annotations',90,'Categories','Figures','','{\"fields\":{\"lemma\":{\"caption\":\"Name\"}}}','annotations~default'),
(43,2,1,NULL,0,'2025-04-18 06:45:20','2025-04-18 06:45:20',1,1,'links','default','default','anno',80,'Annotations','Figure','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf007\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"format\",\"css_style\":\".xml_tag_anno { background-color:#b6ff9d88; }\",\"html_tag\":\"span\",\"html_prefix\":\"[\",\"html_postfix\":\"]\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annotations\"]}}}}','anno~default'),
(44,2,10,NULL,0,'2025-04-18 06:45:35','2025-04-18 06:45:35',1,1,'footnotes','default','default','memo',100,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf08d\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"html_tag\":\"span\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default'),
(45,2,1,NULL,0,'2025-04-18 06:46:12','2025-04-18 06:46:12',1,1,'links','default','default','anno',80,'Annotations','Figure','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf007\",\"font\":\"awesome\",\"style\":\"color: #4dcf20;\"},\"tag_type\":\"format\",\"css_style\":\".xml_tag_anno { background-color:#b6ff9d88; }\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annotations\"]}}}}','anno~default'),
(46,2,10,NULL,0,'2025-04-18 06:46:59','2025-04-18 06:46:59',1,1,'footnotes','default','default','memo',100,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf08d\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"html_prefix\":\"[\",\"html_postfix\":\"]\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default'),
(47,2,10,NULL,0,'2025-04-18 06:47:31','2025-04-18 06:47:31',1,1,'footnotes','default','default','memo',100,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf08d\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"prefix\":\"[\",\"postfix\":\"]\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default'),
(48,2,10,NULL,0,'2025-04-18 06:49:49','2025-04-18 06:49:49',1,1,'footnotes','default','default','memo',100,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf075\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"prefix\":\"[\",\"postfix\":\"]\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default'),
(49,2,1,NULL,0,'2025-04-18 06:50:46','2025-04-18 06:50:46',1,1,'links','default','default','anno',80,'Annotations','Figure','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf5a1\",\"font\":\"awesome\",\"style\":\"color: #4dcf20;\"},\"tag_type\":\"format\",\"css_style\":\".xml_tag_anno { background-color:#b6ff9d88; }\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annotations\"]}}}}','anno~default'),
(50,2,1,NULL,0,'2025-04-18 06:51:30','2025-04-18 06:51:30',1,1,'links','default','default','anno',80,'Annotations','Figure','','{\"group\":\"annos\",\"shortcut\":\"alt+1\",\"toolbutton\":{\"symbol\":\"\\uf5a1\",\"font\":\"awesome\",\"style\":\"color: #4dcf20;\"},\"tag_type\":\"format\",\"css_style\":\".xml_tag_anno { background-color:#b6ff9d88; }\",\"fields\":{\"to\":{\"format\":\"record\",\"required\":true,\"append\":true,\"targets\":{\"properties\":[\"annotations\"]}}}}','anno~default'),
(51,2,10,NULL,0,'2025-04-18 06:51:39','2025-04-18 06:51:39',1,1,'footnotes','default','default','memo',100,'Annotations','Memos','','{\"group\":\"annos\",\"shortcut\":\"alt+2\",\"toolbutton\":{\"symbol\":\"\\uf075\",\"font\":\"awesome\",\"style\":\"color: #c00000;\"},\"tag_type\":\"bracket\",\"prefix\":\"[\",\"postfix\":\"]\",\"css_style\":\".xml_tag_memo > .xml_bracket_open, .xml_tag_memo > .xml_bracket_close { color:#c00000; font-weight:bold }\",\"fields\":{\"name\":{\"format\":\"counter\",\"counter\":\"numeric\"},\"content\":{\"format\":\"xml\"}}}','memo~default');
/*!40000 ALTER TABLE `types` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `version_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `usertype` varchar(50) DEFAULT NULL,
  `name` varchar(1500) DEFAULT NULL,
  `acronym` varchar(1500) DEFAULT NULL,
  `userrole` int(11) DEFAULT NULL,
  `norm_iri` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `userrole` (`userrole`),
  KEY `deleted` (`deleted`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,0,NULL,NULL,'2025-04-17 22:03:08','2025-04-17 22:03:08',NULL,NULL,NULL,'dd','dd',0,'devel'),
(2,2,1,NULL,'2025-04-17 22:03:08','2025-04-17 22:03:08',NULL,NULL,NULL,'dd','dd',0,'devel');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-11-17 22:51:08
